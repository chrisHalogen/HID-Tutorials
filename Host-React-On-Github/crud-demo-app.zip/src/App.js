import React, { useState } from "react";
import ItemList from "./components/ItemList";
import AddItem from "./components/AddItem";
// import "./styles/App.scss";

const App = () => {
  const [items, setItems] = useState([]);

  const handleAdd = (newItem) => {
    setItems([newItem, ...items]);
  };

  const handleUpdate = (updatedItem) => {
    setItems(
      items.map((item) => (item.id === updatedItem.id ? updatedItem : item))
    );
  };

  return (
    <div className="app">
      <h1>React CRUD with API</h1>
      <AddItem onAdd={handleAdd} />
      <ItemList items={items} onUpdate={handleUpdate} />
    </div>
  );
};

export default App;
