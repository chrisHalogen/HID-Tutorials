import React from "react";

const Item = ({ item, onDelete }) => {
  return (
    <div className="item">
      <h3>{item.title}</h3>
      <p>{item.body}</p>
      <button onClick={() => onDelete(item.id)}>Delete</button>
    </div>
  );
};

export default Item;
